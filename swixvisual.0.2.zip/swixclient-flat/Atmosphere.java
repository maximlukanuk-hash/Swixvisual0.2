package com.swixclient.module;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.ParticleTypes;

/**
 * Декоративный снег вокруг камеры: чисто косметика, не меняет погоду на сервере
 * и не видна другим игрокам. Снег рисуется не вручную, а через штатную систему
 * частиц движка (world.addParticle) - поэтому он:
 *  - сам подчиняется настройке "Частицы" (Minimal/Decreased/All) в видео-настройках
 *    и модулю Optimization (если там выключены частицы, снега тоже станет меньше);
 *  - не требует своего рендер-кода и миксинов, то есть не добавляет лишней нагрузки
 *    сверх того, что уже оптимизировано в самом Minecraft.
 */
public class Atmosphere extends Module {
    private final NumberSetting density = add(new NumberSetting("Плотность", 6, 1, 24, 1));
    private final NumberSetting radius = add(new NumberSetting("Радиус", 12, 4, 24, 1));
    private final NumberSetting height = add(new NumberSetting("Высота", 10, 4, 20, 1));
    private final BoolSetting wind = add(new BoolSetting("Ветер", false));

    public Atmosphere() {
        super("Atmosphere", "Декоративный снег вокруг камеры", Category.RENDER);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity player = mc().player;
        ClientWorld world = mc().world;
        if (player == null || world == null) return;

        double r = radius.get();
        double h = height.get();
        int count = density.getInt();

        for (int i = 0; i < count; i++) {
            double x = player.getX() + (world.random.nextDouble() * 2 - 1) * r;
            double z = player.getZ() + (world.random.nextDouble() * 2 - 1) * r;
            double y = player.getEyeY() + world.random.nextDouble() * h;

            double vx = wind.get() ? (world.random.nextDouble() - 0.5) * 0.03 : 0.0;
            double vz = wind.get() ? (world.random.nextDouble() - 0.5) * 0.03 : 0.0;

            world.addParticleClient(ParticleTypes.SNOWFLAKE, x, y, z, vx, -0.08, vz);
        }
    }
}
