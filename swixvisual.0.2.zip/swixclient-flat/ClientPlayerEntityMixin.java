package com.swixclient.mixin;

import com.swixclient.module.AirStuck;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
public class ClientPlayerEntityMixin {
    /** AirStuck: the server never receives our movement, so it keeps us where we froze. */
    @Inject(method = "sendMovementPackets", at = @At("HEAD"), cancellable = true)
    private void swixclient$cancelMovementPackets(CallbackInfo ci) {
        if (AirStuck.isActive()) {
            ci.cancel();
        }
    }
}
