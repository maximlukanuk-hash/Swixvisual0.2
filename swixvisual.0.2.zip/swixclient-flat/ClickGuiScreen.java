package com.swixclient.gui;

import com.swixclient.SwixClient;
import com.swixclient.module.BoolSetting;
import com.swixclient.module.Module;
import com.swixclient.module.NumberSetting;
import com.swixclient.module.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Menu opened with Right Shift (or /swix): categories, search, module tiles. Right click on a tile = its settings. */
public class ClickGuiScreen extends Screen {
    private static final int SIDEBAR = 84;
    private static final int TILE_H = 28;
    private static final int GAP = 4;
    private static final int CAT_H = 17;
    private static final int HEAD_H = 18;
    private static final int ROW_BOOL = 18;
    private static final int ROW_NUM = 28;

    private static final int BG = 0xF0121216;
    private static final int LINE = 0x22FFFFFF;
    private static final int TILE_OFF = 0xFF1C1C21;
    private static final int TILE_OFF_HOVER = 0xFF282830;
    private static final int GRAD_A = 0xFF3D6BFF;
    private static final int GRAD_B = 0xFFD2487A;
    private static final int TEXT = 0xFFFFFFFF;
    private static final int TEXT_DIM = 0xFF9A9AA6;

    private Module.Category selected = Module.Category.MOVEMENT;
    private String search = "";
    private boolean searchFocused;
    private double scroll;
    private Module settingsFor;
    private NumberSetting dragging;

    // layout (recomputed every frame, so the menu follows window resizes)
    private int px, py, pw, ph;
    private int sx, sy, sw;
    private int gx, gy, gw, gh, tw;

    public ClickGuiScreen() {
        super(Text.literal("SwixClient"));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private void layout() {
        pw = Math.min(360, width - 16);
        ph = Math.min(220, height - 16);
        px = (width - pw) / 2;
        py = (height - ph) / 2;

        sx = px + SIDEBAR + 8;
        sy = py + 8;
        sw = pw - SIDEBAR - 16;

        gx = sx;
        gy = py + 28;
        gw = sw;
        gh = ph - 36;
        tw = (gw - GAP) / 2;
    }

    private List<Module> visibleModules() {
        String query = search.trim().toLowerCase(Locale.ROOT);
        List<Module> result = new ArrayList<>();
        for (Module module : SwixClient.MODULES.getModules()) {
            if (query.isEmpty()) {
                if (module.getCategory() == selected) result.add(module);
            } else if (module.getName().toLowerCase(Locale.ROOT).contains(query)) {
                result.add(module);
            }
        }
        return result;
    }

    private double maxScroll(int count) {
        int rows = (count + 1) / 2;
        int content = rows * (TILE_H + GAP) - GAP;
        return Math.max(0, content - gh);
    }

    private int tileX(int index) {
        return gx + (index % 2) * (tw + GAP);
    }

    private int tileY(int index) {
        return gy + (index / 2) * (TILE_H + GAP) - (int) scroll;
    }

    private int catY(int index) {
        return py + 50 + index * (CAT_H + 3);
    }

    // ------------------------------------------------------------------ rendering

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        layout();
        super.render(ctx, mouseX, mouseY, delta);

        List<Module> list = visibleModules();
        scroll = Math.max(0, Math.min(scroll, maxScroll(list.size())));

        // panel
        rounded(ctx, px, py, px + pw, py + ph, 6, BG, BG);
        ctx.fill(px + SIDEBAR, py + 8, px + SIDEBAR + 1, py + ph - 8, LINE);

        // logo + title
        rounded(ctx, px + 8, py + 8, px + 30, py + 30, 4, GRAD_A, GRAD_B);
        text(ctx, "S", px + 16, py + 15, 1.2f, TEXT);
        text(ctx, "SwixClient", px + 35, py + 15, 1.0f, TEXT);

        // categories
        text(ctx, "Основное", px + 10, py + 40, 0.6f, TEXT_DIM);
        Module.Category[] categories = Module.Category.values();
        for (int i = 0; i < categories.length; i++) {
            int cx = px + 6;
            int cy = catY(i);
            int cw = SIDEBAR - 12;
            boolean active = search.trim().isEmpty() && categories[i] == selected;
            boolean hover = inside(mouseX, mouseY, cx, cy, cw, CAT_H);

            if (active) {
                rounded(ctx, cx, cy, cx + cw, cy + CAT_H, 4, GRAD_A, GRAD_B);
            } else if (hover) {
                rounded(ctx, cx, cy, cx + cw, cy + CAT_H, 4, TILE_OFF_HOVER, TILE_OFF_HOVER);
            }
            text(ctx, categories[i].getLabel(), cx + 8, cy + 5, 0.9f, active ? TEXT : TEXT_DIM);
        }

        // search box
        rounded(ctx, sx, sy, sx + sw, sy + 14, 4, TILE_OFF, TILE_OFF);
        String shown;
        int shownColor;
        if (search.isEmpty() && !searchFocused) {
            shown = "Поиск";
            shownColor = TEXT_DIM;
        } else {
            boolean caret = searchFocused && (System.currentTimeMillis() / 500) % 2 == 0;
            shown = search + (caret ? "_" : "");
            shownColor = TEXT;
        }
        text(ctx, shown, sx + 6, sy + 4, 0.85f, shownColor);

        // module tiles
        ctx.enableScissor(gx - 2, gy, gx + gw + 2, gy + gh);
        if (settingsFor != null) {
            renderSettings(ctx);
            ctx.disableScissor();
            return;
        }
        if (list.isEmpty()) {
            text(ctx, "Здесь пока пусто", gx + 2, gy + 4, 0.85f, TEXT_DIM);
        }
        for (int i = 0; i < list.size(); i++) {
            Module module = list.get(i);
            int x = tileX(i);
            int y = tileY(i);
            if (y + TILE_H < gy || y > gy + gh) continue;

            boolean hover = inside(mouseX, mouseY, x, y, tw, TILE_H)
                    && mouseY >= gy && mouseY <= gy + gh;

            if (module.isEnabled()) {
                rounded(ctx, x, y, x + tw, y + TILE_H, 4, GRAD_A, GRAD_B);
            } else {
                int color = hover ? TILE_OFF_HOVER : TILE_OFF;
                rounded(ctx, x, y, x + tw, y + TILE_H, 4, color, color);
            }

            text(ctx, module.getName(), x + 6, y + 6, 0.9f, TEXT);
            if (!module.getSettings().isEmpty()) {
                text(ctx, "...", x + tw - 14, y + 4, 0.9f, module.isEnabled() ? TEXT : TEXT_DIM);
            }
            String desc = textRenderer.trimToWidth(module.getDescription(), (int) ((tw - 10) / 0.6f));
            text(ctx, desc, x + 6, y + 17, 0.6f, module.isEnabled() ? 0xFFE6E6F0 : TEXT_DIM);
        }
        ctx.disableScissor();
    }

    private void text(DrawContext ctx, String value, float x, float y, float scale, int color) {
        MatrixStack matrices = ctx.getMatrices();
        matrices.push();
        matrices.translate(x, y, 0f);
        matrices.scale(scale, scale, 1f);
        ctx.drawText(textRenderer, value, 0, 0, color, false);
        matrices.pop();
    }

    /** Rounded rectangle; c1 -> c2 is a horizontal gradient (pass the same color for a solid fill). */
    private static void rounded(DrawContext ctx, int x1, int y1, int x2, int y2, int radius, int c1, int c2) {
        int w = x2 - x1;
        int h = y2 - y1;
        if (w <= 0 || h <= 0) return;
        int r = Math.max(0, Math.min(radius, Math.min(w, h) / 2));

        if (c1 == c2) {
            ctx.fill(x1 + r, y1, x2 - r, y2, c1);
            for (int i = 0; i < r; i++) {
                int inset = cornerInset(r, r - i - 0.5);
                ctx.fill(x1 + i, y1 + inset, x1 + i + 1, y2 - inset, c1);
                ctx.fill(x2 - 1 - i, y1 + inset, x2 - i, y2 - inset, c1);
            }
            return;
        }

        for (int i = 0; i < w; i++) {
            int inset = 0;
            if (i < r) {
                inset = cornerInset(r, r - i - 0.5);
            } else if (i >= w - r) {
                inset = cornerInset(r, i - (w - r) + 0.5);
            }
            float t = w <= 1 ? 0f : (float) i / (w - 1);
            ctx.fill(x1 + i, y1 + inset, x1 + i + 1, y2 - inset, lerp(c1, c2, t));
        }
    }

    private static int cornerInset(int r, double d) {
        return (int) Math.round(r - Math.sqrt(Math.max(0.0, r * r - d * d)));
    }

    private static int lerp(int a, int b, float t) {
        int al = channel(a, b, t, 24);
        int re = channel(a, b, t, 16);
        int gr = channel(a, b, t, 8);
        int bl = channel(a, b, t, 0);
        return (al << 24) | (re << 16) | (gr << 8) | bl;
    }

    private static int channel(int a, int b, float t, int shift) {
        int ca = (a >>> shift) & 0xFF;
        int cb = (b >>> shift) & 0xFF;
        return Math.round(ca + (cb - ca) * t);
    }

    private static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    // ------------------------------------------------------------------ settings panel

    private static int rowHeight(Setting s) {
        return s instanceof NumberSetting ? ROW_NUM : ROW_BOOL;
    }

    private int trackX1() {
        return gx + 8;
    }

    private int trackX2() {
        return gx + gw - 8;
    }

    private void renderSettings(DrawContext ctx) {
        rounded(ctx, gx - 2, gy, gx + gw + 2, gy + gh, 4, TILE_OFF, TILE_OFF);
        text(ctx, settingsFor.getName(), gx + 6, gy + 5, 1.0f, TEXT);

        String hint = "ПКМ - назад";
        float hintW = textRenderer.getWidth(hint) * 0.6f;
        text(ctx, hint, gx + gw - hintW - 4, gy + 7, 0.6f, TEXT_DIM);
        ctx.fill(gx + 4, gy + HEAD_H, gx + gw - 4, gy + HEAD_H + 1, LINE);

        List<Setting> list = settingsFor.getSettings();
        if (list.isEmpty()) {
            text(ctx, "Нет настроек", gx + 6, gy + HEAD_H + 8, 0.85f, TEXT_DIM);
            return;
        }

        int y = gy + HEAD_H + 4;
        for (Setting s : list) {
            if (s instanceof BoolSetting b) {
                text(ctx, b.getName(), gx + 6, y + 5, 0.85f, TEXT);
                int sx1 = gx + gw - 30;
                int sy1 = y + 3;
                if (b.get()) {
                    rounded(ctx, sx1, sy1, sx1 + 22, sy1 + 11, 5, GRAD_A, GRAD_B);
                    ctx.fill(sx1 + 13, sy1 + 2, sx1 + 20, sy1 + 9, TEXT);
                } else {
                    rounded(ctx, sx1, sy1, sx1 + 22, sy1 + 11, 5, TILE_OFF_HOVER, TILE_OFF_HOVER);
                    ctx.fill(sx1 + 2, sy1 + 2, sx1 + 9, sy1 + 9, TEXT_DIM);
                }
            } else if (s instanceof NumberSetting n) {
                text(ctx, n.getName(), gx + 6, y + 3, 0.85f, TEXT);
                String value = n.format();
                float valueW = textRenderer.getWidth(value) * 0.85f;
                text(ctx, value, gx + gw - valueW - 6, y + 3, 0.85f, TEXT_DIM);

                int x1 = trackX1();
                int x2 = trackX2();
                int ty = y + 17;
                double frac = (n.get() - n.getMin()) / (n.getMax() - n.getMin());
                int fillEnd = x1 + (int) ((x2 - x1) * frac);
                rounded(ctx, x1, ty, x2, ty + 4, 2, TILE_OFF_HOVER, TILE_OFF_HOVER);
                rounded(ctx, x1, ty, Math.max(x1 + 4, fillEnd), ty + 4, 2, GRAD_A, GRAD_B);
                ctx.fill(fillEnd - 2, ty - 2, fillEnd + 2, ty + 6, TEXT);
            }
            y += rowHeight(s);
        }
    }

    private boolean clickSettings(double mx, double my, int button) {
        if (!inside(mx, my, gx - 2, gy, gw + 4, gh)) return false;
        if (button == 1) {
            settingsFor = null;
            dragging = null;
            return true;
        }
        if (button != 0) return true;

        int y = gy + HEAD_H + 4;
        for (Setting s : settingsFor.getSettings()) {
            int h = rowHeight(s);
            if (my >= y && my < y + h) {
                if (s instanceof BoolSetting b) {
                    b.toggle();
                } else if (s instanceof NumberSetting n) {
                    dragging = n;
                    updateSlider(mx);
                }
                return true;
            }
            y += h;
        }
        return true;
    }

    private void updateSlider(double mx) {
        if (dragging == null) return;
        double t = (mx - trackX1()) / (double) (trackX2() - trackX1());
        t = Math.max(0, Math.min(1, t));
        dragging.set(dragging.getMin() + t * (dragging.getMax() - dragging.getMin()));
    }

    // ------------------------------------------------------------------ input

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        layout();

        searchFocused = inside(mouseX, mouseY, sx, sy, sw, 14);
        if (searchFocused) return true;

        Module.Category[] categories = Module.Category.values();
        for (int i = 0; i < categories.length; i++) {
            if (inside(mouseX, mouseY, px + 6, catY(i), SIDEBAR - 12, CAT_H)) {
                selected = categories[i];
                search = "";
                scroll = 0;
                settingsFor = null;
                dragging = null;
                return true;
            }
        }

        if (settingsFor != null) {
            if (clickSettings(mouseX, mouseY, button)) return true;
            return super.mouseClicked(mouseX, mouseY, button);
        }

        if ((button == 0 || button == 1) && mouseY >= gy && mouseY <= gy + gh) {
            List<Module> list = visibleModules();
            for (int i = 0; i < list.size(); i++) {
                if (inside(mouseX, mouseY, tileX(i), tileY(i), tw, TILE_H)) {
                    if (button == 0) {
                        list.get(i).toggle();
                    } else {
                        settingsFor = list.get(i); // right click: open settings
                    }
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (dragging != null && button == 0) {
            layout();
            updateSlider(mouseX);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0) dragging = null;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        double max = maxScroll(visibleModules().size());
        scroll = Math.max(0, Math.min(max, scroll - verticalAmount * 12));
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_ESCAPE && settingsFor != null) {
            settingsFor = null;
            dragging = null;
            return true;
        }
        if (searchFocused) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (!search.isEmpty()) {
                    search = search.substring(0, search.length() - 1);
                    scroll = 0;
                }
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
                searchFocused = false;
                return true;
            }
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (searchFocused && chr >= 32 && chr != 127 && search.length() < 24) {
            search += chr;
            scroll = 0;
            return true;
        }
        return super.charTyped(chr, modifiers);
    }
}
