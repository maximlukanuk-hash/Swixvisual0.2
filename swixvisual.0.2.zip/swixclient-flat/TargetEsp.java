package com.swixclient.module;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

/**
 * Target ESP: while the crosshair is on another player, small AI-avatar icons
 * (billboards, always facing the camera) orbit around that player.
 *
 * ГДЕ ЛЕЖАТ КАРТИНКИ:
 *   src/main/resources/assets/swixclient/textures/ai/deepseek.png
 *   src/main/resources/assets/swixclient/textures/ai/claude.png
 *   src/main/resources/assets/swixclient/textures/ai/gemini.png
 *   src/main/resources/assets/swixclient/textures/ai/grok.png
 *   src/main/resources/assets/swixclient/textures/ai/chatgpt.png
 * Формат: PNG с альфа-каналом (прозрачный фон), квадрат, лучше 64x64 или 128x128.
 * Чтобы добавить ещё иконку: положи PNG в ту же папку и добавь имя в массив NAMES.
 *
 * Оптимизация: ни одного new в цикле рендера (scratch-массивы), RenderLayer'ы
 * создаются один раз, иконки с одной текстурой рисуются одним draw-вызовом (всего <= число текстур).
 */
public class TargetEsp extends Module {
    /** Имена файлов без ".png" (папка textures/ai/). Порядок = порядок появления иконок вокруг цели. */
    private static final String[] NAMES = {"deepseek", "claude", "gemini", "grok", "chatgpt"};

    private static final int MAX_ICONS = 15;
    private static final float TAU = (float) (Math.PI * 2.0);
    private static final float FADE_IN = 6.0f;   // alpha per second
    private static final float FADE_OUT = 4.0f;

    private static final RenderLayer[] LAYERS = new RenderLayer[NAMES.length];

    static {
        for (int i = 0; i < NAMES.length; i++) {
            LAYERS[i] = RenderLayer.getEntityTranslucent(
                    Identifier.of("swixclient", "textures/ai/" + NAMES[i] + ".png"));
        }
    }

    // settings (right click on the tile in the menu)
    private final NumberSetting count = add(new NumberSetting("Иконки", 5, 1, MAX_ICONS, 1));
    private final NumberSetting size = add(new NumberSetting("Размер", 0.3, 0.1, 0.8, 0.05));
    private final NumberSetting radius = add(new NumberSetting("Радиус", 0.9, 0.4, 2.0, 0.1));
    private final NumberSetting speed = add(new NumberSetting("Скорость", 1.0, 0.2, 3.0, 0.1));
    private final BoolSetting chaos = add(new BoolSetting("Хаотично", false));

    // per-icon random-looking phases, computed once
    private static final float[] SEED = new float[MAX_ICONS];

    static {
        for (int i = 0; i < MAX_ICONS; i++) {
            SEED[i] = (i * 2.399963f) % TAU; // golden angle, evenly spread phases
        }
    }

    // scratch buffers (camera-relative position, size, spin) - no allocations while rendering
    private final float[] px = new float[MAX_ICONS];
    private final float[] py = new float[MAX_ICONS];
    private final float[] pz = new float[MAX_ICONS];
    private final float[] psize = new float[MAX_ICONS];
    private final float[] pspin = new float[MAX_ICONS];

    private PlayerEntity target;
    private float alpha;
    private long lastNanos;

    public TargetEsp() {
        super("TargetEsp", "ИИ-иконки вокруг игрока в прицеле", Category.RENDER);
        WorldRenderEvents.LAST.register(this::render);
    }

    @Override
    protected void onDisable() {
        target = null;
        alpha = 0f;
    }

    /** The player under the crosshair (vanilla raytrace: reach distance), or null. */
    private static PlayerEntity lookedAtPlayer(MinecraftClient mc) {
        HitResult hit = mc.crosshairTarget;
        if (hit instanceof EntityHitResult ehr
                && ehr.getEntity() instanceof PlayerEntity p
                && p != mc.player
                && !p.isSpectator()) {
            return p;
        }
        return null;
    }

    private void render(WorldRenderContext ctx) {
        if (!isEnabled()) return;
        MinecraftClient mc = mc();
        if (mc.world == null || mc.player == null) return;

        // smooth fade in/out, independent of FPS
        long now = System.nanoTime();
        float dt = lastNanos == 0 ? 0f : Math.min(0.1f, (now - lastNanos) / 1.0e9f);
        lastNanos = now;

        PlayerEntity looked = lookedAtPlayer(mc);
        if (looked != null) {
            target = looked;
            alpha = Math.min(1f, alpha + dt * FADE_IN);
        } else {
            alpha = Math.max(0f, alpha - dt * FADE_OUT);
        }
        if (alpha <= 0.01f) {
            target = null;
            return;
        }
        if (target == null || !target.isAlive() || target.getWorld() != mc.world) {
            target = null;
            alpha = 0f;
            return;
        }

        MatrixStack matrices = ctx.matrixStack();
        VertexConsumerProvider consumers = ctx.consumers();
        if (matrices == null || consumers == null) return;

        Camera camera = ctx.camera();
        Vec3d cam = camera.getPos();
        float td = mc.getRenderTickCounter().getTickDelta(false);
        float time = mc.world.getTime() + td; // ticks, smooth

        // target center (interpolated), relative to the camera
        double cx = MathHelper.lerp(td, target.prevX, target.getX()) - cam.x;
        double cy = MathHelper.lerp(td, target.prevY, target.getY()) + target.getHeight() * 0.5 - cam.y;
        double cz = MathHelper.lerp(td, target.prevZ, target.getZ()) - cam.z;

        int n = count.getInt();
        float r = (float) radius.get();
        float sp = (float) speed.get();
        float baseSize = (float) size.get();
        boolean wild = chaos.get();
        float halfH = target.getHeight() * 0.5f;

        // 1) positions of all icons
        for (int i = 0; i < n; i++) {
            float base = i * TAU / n;
            float ang = base + time * 0.06f * sp;
            float rr = r;
            float yy;
            if (wild) {
                ang += MathHelper.sin(time * 0.05f * sp + SEED[i]) * 1.2f;
                rr = r * (0.75f + 0.35f * MathHelper.sin(time * 0.09f * sp + SEED[i] * 2f));
                yy = MathHelper.sin(time * 0.07f * sp + SEED[i] * 3f) * halfH * 0.9f;
            } else {
                yy = MathHelper.sin(time * 0.08f * sp + base * 2f) * 0.35f;
            }
            px[i] = (float) cx + MathHelper.cos(ang) * rr;
            py[i] = (float) cy + yy;
            pz[i] = (float) cz + MathHelper.sin(ang) * rr;
            psize[i] = baseSize * (0.85f + 0.15f * MathHelper.sin(time * 0.15f * sp + SEED[i]));
            pspin[i] = MathHelper.sin(time * 0.04f * sp + SEED[i]) * 25f; // gentle wobble in degrees
        }

        // 2) draw grouped by texture: one buffer + one draw call per texture
        int a = (int) (255 * alpha);
        for (int t = 0; t < LAYERS.length; t++) {
            VertexConsumer buffer = null;
            for (int i = t; i < n; i += LAYERS.length) {
                if (buffer == null) buffer = consumers.getBuffer(LAYERS[t]);
                quad(buffer, matrices, camera, px[i], py[i], pz[i], psize[i], pspin[i], a);
            }
            if (buffer != null && consumers instanceof VertexConsumerProvider.Immediate imm) {
                imm.draw(LAYERS[t]);
            }
        }
    }

    /** One camera-facing quad (billboard): rotate by the camera rotation so it always faces the player. */
    private static void quad(VertexConsumer buf, MatrixStack matrices, Camera camera,
                             float x, float y, float z, float size, float spinDeg, int a) {
        matrices.push();
        matrices.translate(x, y, z);
        matrices.multiply(camera.getRotation());
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(spinDeg));
        Matrix4f m = matrices.peek().getPositionMatrix();
        float h = size * 0.5f;
        int light = LightmapTextureManager.MAX_LIGHT_COORDINATE; // fullbright, icons don't get dark
        int overlay = OverlayTexture.DEFAULT_UV;

        buf.vertex(m, -h, -h, 0f).color(255, 255, 255, a).texture(0f, 1f).overlay(overlay).light(light).normal(0f, 0f, 1f);
        buf.vertex(m, h, -h, 0f).color(255, 255, 255, a).texture(1f, 1f).overlay(overlay).light(light).normal(0f, 0f, 1f);
        buf.vertex(m, h, h, 0f).color(255, 255, 255, a).texture(1f, 0f).overlay(overlay).light(light).normal(0f, 0f, 1f);
        buf.vertex(m, -h, h, 0f).color(255, 255, 255, a).texture(0f, 0f).overlay(overlay).light(light).normal(0f, 0f, 1f);
        matrices.pop();
    }
}
