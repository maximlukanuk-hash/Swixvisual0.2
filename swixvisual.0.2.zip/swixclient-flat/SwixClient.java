package com.swixclient;

import com.swixclient.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;

public class SwixClient implements ClientModInitializer {
    public static final String MOD_ID = "swixclient";
    public static final ModuleManager MODULES = new ModuleManager();

    @Override
    public void onInitializeClient() {
        MODULES.init();
        TungMace.init();
    }
}
