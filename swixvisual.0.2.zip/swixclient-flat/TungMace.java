package com.swixclient;

import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.ResourcePackActivationType;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * Кастомная булава "Tung Tung Sahur": встроенный ресурспак, который меняет вид обычной булавы.
 * Включён по умолчанию. Выключить: Настройки -> Ресурспаки -> "Tung Mace".
 * Меняется только внешний вид (клиентская текстура), урон и свойства булавы те же.
 * Свою картинку можно положить в resourcepacks/tung_mace/assets/swixclient/textures/item/tung_mace.png
 */
public final class TungMace {
    private TungMace() {}

    public static void init() {
        FabricLoader.getInstance().getModContainer(SwixClient.MOD_ID).ifPresent(container ->
                ResourceManagerHelper.registerBuiltinResourcePack(
                        Identifier.of(SwixClient.MOD_ID, "tung_mace"),
                        container,
                        Text.literal("Tung Mace"),
                        ResourcePackActivationType.DEFAULT_ENABLED));
    }
}
